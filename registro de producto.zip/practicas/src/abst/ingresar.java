package abst;

import javax.swing.JOptionPane;

public  class ingresar extends pract {
@Override
public void op() {
	try {
	System.out.println("digite elementos a ingresar");
int e=tc.nextInt();
	String []elementos=new String [e];
tc.nextLine();
	


String [] art= new String [e];	
int []precio=  new int[e];
for (int i = 0; i < e; i++) {
System.out.println("producto "+(i+1));
tc.nextLine();

art[i]=tc.nextLine();
String dato;
do {
  dato = JOptionPane.showInputDialog("Ingrese el nombre del producto (solo letras):");
} while (!dato.matches("[a-zA-Z ]+"));
art[i]=dato;
 


}
for (int i = 0; i < e; i++) {
System.out.println("precio del producto " +(i+1) +"   Es de: ");
int  numero;

    System.out.println("ingrese el precio");
numero=tc.nextInt(); 



precio[i]=tc.nextInt();

}
System.out.println("imprimiendo tabla ");
System.out.println("-----------------------------------------------------------");
for (int i = 0; i < e; i++) {

	System.out.println("producto :" + art[i] +  " precio es de :"+precio[i]  );
}
System.out.println("-----------------------------------------------------------");

	}catch(Exception e) {
		System.out.println("error de dato ");
	}


}


}
