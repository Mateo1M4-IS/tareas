package abst;

import java.util.Scanner;

public abstract class pract {

	Scanner tc= new Scanner(System.in);
	
public void op() {
	
}


}
