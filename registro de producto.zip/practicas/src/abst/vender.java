package abst;

public class vender extends pract{
@Override
	public void op() {
System.out.println("elija el producto de loc cuales tenemos dsiponibles "); 
	System.out.println("Lavadora opcion 1");
System.out.println("Pan opcion 2");
	System.out.println("Luz opcion 3");

	int p=tc.nextInt();
	try {
	if(p==1) {
		int lava=120;
	System.out.println("ingrese cantidad lavadoras a vender");
	int x=tc.nextInt();
	int c=lava*x;
	System.out.println("usted lleva "+x+ " lavadoras su total es :"+c );
	}

	if(p==2) {
		int pan=20;
	System.out.println("ingrese cantidad lavadoras a vender");
	int x=tc.nextInt();
	int c=pan*x;
	System.out.println("usted lleva "+x+ " lavadoras su total es :"+c );
	}

	if(p==3) {
		int luz=1120;
	System.out.println("ingrese cantidad lavadoras a vender");
	int x=tc.nextInt();
	int c=luz*x;
	System.out.println("usted lleva "+x+ " lavadoras su total es :"+c );
	}
	}catch(Exception e) {
		System.out.println("no puedes hacer eso ");
	}
	
	
}
}

