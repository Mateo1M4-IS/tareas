package abst;

import java.util.Scanner;

import javax.swing.JOptionPane;


	public class main{
public static void main(String[] args) {
		String eleccion = null;  
	Scanner tc =new Scanner(System.in);
		
		        
		   System.out.println("hola digite una opcion \n opcion A es ingresar nueva mercancia \n opcion B es vender lo que tenemos \nOpcion C para salir");
		      eleccion=tc.nextLine();
		            if (eleccion.equals("A")) {
		        pract l=new ingresar();
		        l.op();
		         
		            }
		            if (eleccion.equals("B")) {
		              pract m=new vender();
		              m.op();
		            }
		            if (eleccion.equals("C")) {
		             System.out.println("hasta la proxima ");
		           
		            }
		        
}
}	

		

		

